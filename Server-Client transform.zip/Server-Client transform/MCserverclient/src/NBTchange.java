import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.jnbt.ByteTag;
import org.jnbt.CompoundTag;
import org.jnbt.NBTInputStream;
import org.jnbt.NBTOutputStream;
import org.jnbt.Tag;

public class NBTchange {
	static void changeNbt(String filePath){
		try {
			FileInputStream FIS=new FileInputStream(filePath);
			NBTInputStream nbtStream=new NBTInputStream(FIS);
	
			CompoundTag nxt=(CompoundTag) (nbtStream.readTag());
			nbtStream.close();
			FIS.close();
			
			CompoundTag  whole=(CompoundTag) ((Map)nxt.getValue()).get("Data");
			Map<String,Tag> data= whole.getValue();
			Map<String,Tag> dataClone=new HashMap<String,Tag>();
			for(String k:data.keySet()){
				dataClone.put(k, data.get(k));
			}
			dataClone.put("allowCommands", new ByteTag ("allowCommands",(byte) 1));
			CompoundTag clone=new CompoundTag("Data",dataClone);
			Map<String,Tag> e=new HashMap<String,Tag>();
			e.put("Data",clone);
			CompoundTag editedWhole=new CompoundTag("",e);
			FileOutputStream FOS=new FileOutputStream(filePath);
			NBTOutputStream nbtOutStream=new NBTOutputStream(FOS);
			nbtOutStream.writeTag(editedWhole);
			nbtOutStream.close();
			FOS.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
