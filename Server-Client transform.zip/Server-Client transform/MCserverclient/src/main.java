
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.util.Comparator;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthSeparatorUI;

import com.jcraft.jsch.*;

public class main {
	static String PAPERMCPATH = "paper";
	static String CLIENTMCPATH = System.getProperty("user.home") + "/Library/Application Support/minecraft/";
	static String downloadLocalWorld = "testserverdownload";
	static boolean override = true;
	static JSch jsch = new JSch();

	static Log log = new consoleLog();

	public static void main(String[] args) {
		try {
			jsch.setKnownHosts("~/.ssh/known_hosts");
			/*
			 * Make sure you have ur server in the known_hosts file
			 * https://serverfault.com/a/321181
			 */
		} catch (JSchException e) {
			e.printStackTrace();
		}

		downloadFromServer();
		//uploadToServer();
	}

	static void uploadToServer() {

		try {
			Session session = jsch.getSession("minecraft", "server.larrys.tech", 22);
			session.setPassword("ThrowawayPassword");
			session.connect();
			log.log("Connecting ssh");
			;
			Channel channel = session.openChannel("sftp");

			ChannelSftp c = (ChannelSftp) channel;
			channel.connect();
			c.lcd(CLIENTMCPATH);
			c.lcd("saves");
			c.lcd(downloadLocalWorld);
			c.cd("paper");
			// System.out.println("cp ");

			uploadtoserver(session, c, "/region", "/world");
			uploadtoserver(session, c, "/stats", "/world");
			uploadtoserver(session, c, "/data", "/world");
			uploadtoserver(session, c, "/playerdata", "/world");
			uploadtoserver(session, c, "/advancements", "/world");
			uploadtoserver(session, c, "/DIM-1", "/world_nether");
			uploadtoserver(session, c, "/DIM1", "/world_the_end");

			// c.cd(PAPERMCPATH);

			// c.put();

		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static void uploadtoserver(Session session, ChannelSftp c, String directoryLocal, String directoryRemoteContainer) {
		String zipCommand = "cd " + c.lpwd().replace(" ", "\\ ") + ";zip archive.zip region";

		try {

			ProcessBuilder builder = new ProcessBuilder("/bin/bash");
			Process p = null;
			try {
				p = builder.start();
			} catch (IOException e) {
				System.out.println(e);
			}
			BufferedWriter in = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
			in.write("cd " + c.lpwd().replace(" ", "\\ "));
			System.out.println("cd " + c.lpwd().replace(" ", "\\ "));
			in.newLine();
			in.flush();
			in.write("zip -qr archive.zip region");
			in.newLine();
			in.flush();
			in.write("ls -l");
			in.newLine();
			in.flush();
			in.write("exit");
			in.newLine();
			in.flush();
			p.waitFor();

		    Scanner s = new Scanner( p.getInputStream() );
		    while (s.hasNext())
		    {
		        System.out.println( s.nextLine() );
		    }
		    s.close();
		    System.out.println(c.pwd());
			//System.out.println(c.lpwd()+"/archive.zip);
			c.put("archive.zip",".",ChannelSftp.OVERWRITE);
			//System.out.println("rm "+c.lpwd().replace(" ", "\\ ")+"/archive.zip","",ChannelSftp.OVERWRITE);
		    //(new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(new String[] {"rm",c.lpwd()+"/archive.zip"}).getInputStream()))).lines().forEach(System.out::println);
		    System.out.println("unzip "+c.pwd()+"/archive.zip -d "+c.pwd()+directoryRemoteContainer);
		    sendCommand(session,"rm -r "+c.pwd()+directoryRemoteContainer);
		    sendCommand(session,"unzip -o "+c.pwd()+"/archive.zip -d "+c.pwd()+directoryRemoteContainer);
		    sendCommand(session,"rm "+PAPERMCPATH+"/archive.zip");

		} catch (IOException e) {
			e.printStackTrace();
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static void downloadFromServer() {

		try {

			Session session = jsch.getSession("minecraft", "server.larrys.tech", 22);
			session.setPassword("ThrowawayPassword");
			session.connect();
			log.log("Connecting ssh");
			;
			Channel channel = session.openChannel("sftp");

			ChannelSftp c = (ChannelSftp) channel;
			channel.connect();

			c.lcd(CLIENTMCPATH);
			c.lcd("saves");
			File f = new File(c.lpwd() + "/" + downloadLocalWorld);
			if (f.exists()) {
				if (override) {
					log.log("override true, overriding world " + downloadLocalWorld);
					;

					Files.walk(f.toPath()).sorted(Comparator.reverseOrder()).forEach(s -> {
						log.log("Deleting " + s);
						s.toFile().delete();
					});
				} else {
					log.log("ERROR: FILE OREADY EXIST");
					return;

				}
			}

			f.mkdirs();

			log.log("Making " + f);
			c.lcd(downloadLocalWorld);

			// c.get("world/region",);

			// System.out.println(unzipStr);
			// Process proc = Runtime.getRuntime().exec(unzipStr);
			downloadfromserver(session, c, "/world/data", "/");
			downloadfromserver(session, c, "/world/playerdata", "/");
			downloadfromserver(session, c, "/world/stats", "/");
			downloadfromserver(session, c, "/world/region", "/");
			downloadfromserver(session, c, "/world/advancements", "/");
			downloadfromserver(session, c, "/world_nether/DIM-1", "/");
			downloadfromserver(session, c, "/world_the_end/DIM1", "/");
			log.log("\nDownloading /world/level.dat");

			c.get(c.pwd() + "/" + PAPERMCPATH + "/world/level.dat", c.lpwd());

			Thread.sleep(1000);
			ProcessBuilder processBuilder = new ProcessBuilder();

			processBuilder.command("rm", "-R", c.lpwd() + "/" + PAPERMCPATH);
			processBuilder.start();

			log.log("Editing NBT");
			NBTchange.changeNbt(c.lpwd() + "/level.dat");

			log.log("Done");
			session.disconnect();
		} catch (JSchException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	static void downloadfromserver(Session session, ChannelSftp c, String directory, String directoryTo) {
		try {

			log.log("\nDownloading " + directory);

			String compressCommand = String.format("zip -qr %s %s", "archive.zip", PAPERMCPATH + directory);

			log.log("Compressing file on server: " + compressCommand);
			sendCommand(session, compressCommand);

			log.log("Sending file from server to client");

			c.get(c.pwd() + "/archive.zip", c.lpwd());
			sendCommand(session, "rm archive.zip");

			log.log("Decompressing");

			ProcessBuilder processBuilder = new ProcessBuilder();
			processBuilder.command("unzip", "-o", c.lpwd() + "/archive.zip", "-d", c.lpwd());
			Process p = processBuilder.start();
			try {
				p.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			processBuilder = new ProcessBuilder();
			processBuilder.command("rm", c.lpwd() + "/archive.zip");
			processBuilder.start();
			log.log("Moving file");

			processBuilder = new ProcessBuilder();
			processBuilder.command("mv", c.lpwd() + "/" + PAPERMCPATH + directory, c.lpwd() + directoryTo);
			processBuilder.start();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// Runtime.getRuntime().exec("rm "+c.lpwd()+"/archive.zip");
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static String sendCommand(Session session,
			String command) {/* https://stackoverflow.com/a/11902536/5771000 */
		StringBuilder outputBuffer = new StringBuilder();

		try {

			ChannelExec channel = (ChannelExec) session.openChannel("exec");
			channel.setCommand(command);
			InputStream commandOutput = channel.getInputStream();
			channel.connect();
			int readByte;
			readByte = commandOutput.read();

			while (commandOutput.available() > 0) {
				while (readByte != 0xffffffff) {
					outputBuffer.append((char) readByte);
					readByte = commandOutput.read();
				}
				try {
					Thread.sleep(100);
				} catch (Exception ee) {
				}
			}
			channel.disconnect();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (outputBuffer.toString());

	}

	static class consoleLog extends Log {
		@Override
		void log(Object out) {
			System.out.println(out);
		}

		@Override
		void err(Object out) {
			System.err.println(out);
		}
	}

	static class Log {
		void log(Object out) {

		}

		void err(Object out) {

		}
	}

}
